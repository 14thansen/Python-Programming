"""
The purpose of this program is to change the properties of an image.
"""

from images import Image

def lighten(image, change):
	for x in range(image.getWidth()):
		for y in range(image.getHeight()):
			(r, g, b) = image.getPixel(x, y)
			if r + change < 255:
				r += change
			else:
				r = 255
			if g + change < 255:
				g += change
			else:
				g = 255
			if b + change < 255:
				b += change
			else:
				b = 255
			image.setPixel(x, y, (r, g, b))
	image.draw()

def darken(image, change):
	for x in range(image.getWidth()):
		for y in range(image.getHeight()):
			(r, g, b) = image.getPixel(x, y)
			if r - change > 0:
				r -= change
			else:
				r = 0
			if g - change > 0:
				g -= change
			else:
				g = 0
			if b - change > 0:
				b -= change
			else:
				b = 0
			image.setPixel(x, y, (r, g, b))
	image.draw()

def colorFilter(image, change):
	for x in range(image.getWidth()):
		for y in range(image.getHeight()):
			(r, g, b) = image.getPixel(x, y)
			if r + change[0] < 255 and r + change[0] > 0:
				r += change[0]
			else:
				if change[0] > 0:
					r = 255
				else:
					r = 0
			if g + change[1] < 255 and g + change[1] > 0:
				g += change[1]
			else:
				if change[1] > 0:
					g = 255
				else:
					g = 0
			if b + change[2] < 255 and b + change[2] > 0:
				b += change[2]
			else:
				if change[2] > 0:
					b = 255
				else:
					b = 0
			image.setPixel(x, y, (r, g, b))
	image.draw()
	
def main():
	image = Image("sample.gif")
	image1 = image.clone()
	image2 = image.clone()
	image3 = image.clone()
	
	darker = int(input("Darken by: "))
	lighter = int(input("Lighten by: "))
	colorR = int(input("	Red value: "))
	colorG = int(input("	Green value: "))
	colorB = int(input("	Blue value: "))
	
	print("\nClose one window to see the next...")
	colors = (colorR, colorG, colorB)
	image.draw()
	darken(image1, darker)
	lighten(image2, lighter)
	colorFilter(image3, colors)
	
main()