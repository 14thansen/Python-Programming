"""
The purpose of this program is to sharpen the edges of an image.
"""

from images import Image

def detectEdges(image, amount, sharper):
	
	def average(triple):
		(r, g, b) = triple
		return (r + g + b) // 3
		
	newImage = image.clone()
	
	for y in range(image.getHeight() - 1):
		for x in range(1, image.getWidth()):
			oldPixel = image.getPixel(x, y)
			leftPixel = image.getPixel(x - 1, y)
			bottomPixel = image.getPixel(x, y + 1)
			oldLum = average(oldPixel)
			leftLum = average(leftPixel)
			bottomLum = average(bottomPixel)
			if abs(oldLum - leftLum) > amount or abs(oldLum - bottomLum) > amount:
				(r, g, b) = image.getPixel(x, y)
				newImage.setPixel(x, y, (r - sharper, g - sharper, b - sharper))
	newImage.draw()
	
detectEdges(Image("sample.gif"), 10, 10)


