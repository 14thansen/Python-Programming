"""
the purpose of this program is to create an abstract picture.
"""

from images import Image
import random

def color(image, x1, y1, x2, y2):
	randColor = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
	for x in range(x1, x2):
		for y in range(y1, y2):
			image.setPixel(x, y, randColor)
			
def rectangles(image, level, count, x1, y1, x2, y2):
	if level >= 0:
		if count % 2 == 0:
			color(image, x1, y1, x2, y2)
			rectangles(image, level - 1, count + 1, x1, y1, x2//3, y2)
		else:
			color(image, x1, y1, x2, y2)
			rectangles(image, level - 1, count + 1, x1, y1, x2, y2//3)
			
def main():
	level = int(input("How many passes?: "))
	print("Wait one moment please while we create your image...")
	image = Image(800, 800)
	randColor = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
	for x in range(image.getWidth()):
		for y in range(image.getHeight()):
			image.setPixel(x, y, randColor)
	rectangles(image, level, 0, 1, 0, image.getWidth(), image.getHeight())
	image.draw()
	
main()