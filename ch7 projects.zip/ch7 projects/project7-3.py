"""
The purpose of this program is to draw a koch snowflake at different levels.
"""

from turtle import Turtle

def drawLine(t, length, level):
	#draw fractured lines
	if level == 0:
		t.forward(length)
	else:
		for turn in [60, -120, 60, 0]:
			drawLine(t, length // 3, level - 1)
			t.left(turn)
	
def drawKoch(t, length, level):
	#draw each side
	t.fillcolor("white")
	t.begin_fill()
	for side in range(3):
		drawLine(t, length, level)
		t.left(-120)
		
	t.end_fill()
	t.hideturtle()
	t.getscreen()._root.mainloop()
		
def main():
	t = Turtle()
	t.pensize(5)
	t.color("sky blue")
	t.screen.bgcolor("black")
	t.up()
	t.goto(-250, 150)
	t.down()
	t.speed("fast")
	t.hideturtle()
	#(turtle, line size, level)
	drawKoch(t, 500, 3)

main()