"""
The purpose of this program is to preform basic calculations with a GUI based format.
"""
from tkinter import *

class Calc(Frame):
	"""This class represents a calculator interface."""
	def __init__(self):
		"""Sets up the window and widgets."""
		Frame.__init__(self)
		self.master.title("Calculator")
		self.grid()
		
		self._dataPane = Frame(self)
		self._dataPane.grid(row = 0, column = 0)
		self._displayVar = StringVar()
		self._displayBox = Entry(self._dataPane, textvariable = self._displayVar,
				width = 15, justify = RIGHT)
		self._displayBox.grid(row = 0, column = 0)
		
		self._buttonPane = Frame(self)
		self._buttonPane.grid(row = 1, column = 0)
		self._clearBtn = Button(self._buttonPane, text = "C", command = self._clear)
		self._clearBtn.grid(row = 3, column = 0)
		self._enterBtn = Button(self._buttonPane, text = "=", command = self._enter)
		self._enterBtn.grid(row = 3, column = 2)
		self._buttons = []
		self._buttons.append(Button(self._buttonPane, text = "0", command = self._numbers))
		self._buttons[0].grid(row = 3, column = 1)
		number = 1
		for i in range(2, -1, -1):
			for j in range(0, 3):
				self._buttons.append(Button(self._buttonPane, text = str(number), command = lambda newVar = number: self._numbers(newVar)))
				self._buttons[number].grid(row = i, column = j)
				number += 1
		
		self._divideBtn = Button(self._buttonPane, text = "/", command = self._divide)
		self._timesBtn = Button(self._buttonPane, text = "*", command = self._times)
		self._minusBtn = Button(self._buttonPane, text = "-", command = self._minus)
		self._addBtn = Button(self._buttonPane, text = "+", command = self._add)
		self._divideBtn.grid(row = 0, column = 3)
		self._timesBtn.grid(row = 1, column = 3)
		self._minusBtn.grid(row = 2, column = 3)
		self._addBtn.grid(row = 3, column = 3)
	
	def _numbers(self, number):
		text = self._displayVar.get()
		text += str(number)
		self._displayVar.set(text)
	
	def _divide(self):
		self._numbers("/")
	def _times(self):
		self._numbers("*")
	def _minus(self):
		self._numbers("-")
	def _add(self):
		self._numbers("+")
	
	def _clear(self):
		self._displayVar.set("")
		
	def _enter(self):
		text = self._displayVar.get()
		ans = eval(text)
		self._displayVar.set(ans)
		
def main():
	Calc().mainloop()
main()