"""
The purpose of this project is to create a blackjack game.
"""

from tkinter import *
from cards import Card, Deck

class Player(object):
	"""This class represents a player in
	a blackjack game."""

	def __init__(self, cards):
		self._cards = cards
		
	def getCardsP(self):
		"""Returns string rep of cards and points."""
		return self._cards

	def hit(self, card):
		self._cards.append(card)

	def getPoints(self):
		"""Returns the number of points in the hand."""
		count = 0
		for card in self._cards:
			if card.rank > 9:
				count += 10
			elif card.rank == 1:
				count += 11
			else:
				count += card.rank
		# Deduct 10 if Ace is available and needed as 1
		for card in self._cards:
			if count <= 21:
				break
			elif card.rank == 1:
				count -= 10
		return count

	def hasBlackjack(self):
		"""Dealt 21 or not."""
		return len(self._cards) == 2 and self.getPoints() == 21 
		
class Dealer(Player):
	"""Like a Player, but with some restrictions."""

	def __init__(self, cards):
		"""Initial state: show one card only."""
		Player.__init__(self, cards)
		self._showOneCard = True

	def getCardsD(self):
		"""Return just one card if not hit yet."""
		if self._showOneCard:
			return self._cards[0]
		else:
			return Player.getCardsP(self)

	def hit(self, deck):
		"""Add cards while points < 17,
		then allow all to be shown."""
		self._showOneCard = False
		while self.getPoints() < 17:
			self._cards.append(deck.deal())

class blackJack(Frame):
	def __init__(self):
		Frame.__init__(self)
		"""Set up the stage"""
		self.master.title("Black Jack")
		self.grid()
		self._deck = Deck()
		self._deck.shuffle()
		
		"""Deal 2 cards to player and dealer"""
		self._player = Player([self._deck.deal(), self._deck.deal()])
		self._dealer = Dealer([self._deck.deal(), self._deck.deal()])
		
		"""Set up dealer cards"""
		self._dealerPane = Frame(self)
		self._dealerPane.grid(row = 0, column = 0)
		self._textLabelD = Label(self._dealerPane, text = "Dealer: ")
		self._textLabelD.grid(row = 0, column = 0)
		self._cardBack = PhotoImage(file = Card.BACK_NAME)
		self._cardsD = self._dealer.getCardsD()
		self._cardImageD = []
		self._imageLabelD = []
		self.showCardsD()
		
		"""Set up the buttons"""
		self._buttonPane = Frame(self)
		self._buttonPane.grid(row = 1, column = 0)
		self._hitButton = Button(self._buttonPane, text = "Hit Me", command = self._hit)
		self._hitButton.grid(row = 0, column = 0)
		self._passButton = Button(self._buttonPane, text = "Pass", command = self._pass)
		self._passButton.grid(row = 0, column = 1)
		self._newButton = Button(self._buttonPane, text = "New Game", command = self._newGame,
				state = "disabled")
		self._newButton.grid(row = 0, column = 2)
		
		"""Set up the player cards"""
		self._playerPane = Frame(self)
		self._playerPane.grid(row = 2, column = 0)
		self._textLabelP = Label(self._playerPane, text = "Player: ")
		self._textLabelP.grid(row = 0, column = 0)
		self._cardsP = self._player.getCardsP()
		self._cardImageP = []
		self._imageLabelP = []
		self.showCardsP()
		
		"""Set up the status display"""
		self._textPane = Frame(self)
		self._textPane.grid(row = 3, column = 0)
		self._textLabel = Label(self._textPane, text = "You have " + str(self._player.getPoints()) + " points")
		self._textLabel.grid(row = 0, column = 0)
		
	def showCardsD(self):
		"""Shows the dealer's cards"""
		i = 0
		self._cardImageD.clear()
		self._imageLabelD.clear()
		if self._dealer._showOneCard:
			self._cardImageD.append(PhotoImage(file = self._cardsD.fileName))
			self._imageLabelD.append(Label(self._dealerPane, image = self._cardImageD[0]))
			self._imageLabelD.append(Label(self._dealerPane, image = self._cardBack))
			self._imageLabelD[0].grid(row = 1, column = 0, rowspan = 3)
			self._imageLabelD[1].grid(row = 1, column = 1, rowspan = 3)
		else:
			for card in self._cardsD:
				self._cardImageD.append(PhotoImage(file = card.fileName))
				self._imageLabelD.append(Label(self._dealerPane, image = self._cardImageD[i]))
				self._imageLabelD[i].grid(row = 1, column = i, rowspan = 3)
				i += 1
	
	def showCardsP(self):
		"""Shows the player's cards"""
		i = 0
		self._cardImageP.clear()
		self._imageLabelP.clear()
		for card in self._cardsP:
			self._cardImageP.append(PhotoImage(file = card.fileName))
			self._imageLabelP.append(Label(self._playerPane, image = self._cardImageP[i]))
			self._imageLabelP[i].grid(row = 1, column = i, rowspan = 3)
			i += 1
	
	def _hit(self):
		"""Deals a single card to the player.
		Also checks if players points have gone over 21"""
		points = self._player.getPoints()
		if points < 21:
			card = self._deck.deal()
			self._player.hit(card)
			self._cardsP = self._player.getCardsP()
			self.showCardsP()
			points = self._player.getPoints()
		self._textLabel.config(text = "You have " + str(points) + " points")
		if points > 21:
			self._pass()
				
	def _pass(self):
		"""Deals cards to dealer and finishes the game"""
		self._newButton.config(state = "normal")
		self._dealer.hit(self._deck)
		self._cardsD = self._dealer.getCardsD()
		self.showCardsD()
		text = self._textLabel.cget("text")
		points = self._dealer.getPoints()
		text += "\nDealer has " + str(points) + " points"
		self._textLabel.config(text = text)
		text = self._win()
		
	def _win(self):
		"""Checks how many points the player and the dealer 
		have and awards credit where credit is due."""
		dPoints = self._dealer.getPoints()
		pPoints = self._player.getPoints()
		text = self._textLabel.cget("text")
		if dPoints >= pPoints and dPoints <= 21:
			text += "\nDealer Wins!"
		elif pPoints <= 21:
			text = self._textLabel.cget("text")
			text += "\nYou Win!"
		else:
			if pPoints > 21:
				text += "\nYou bust"
			if dPoints > 21:
				text += "\nDealer busts"
				text += "\nYou both lose!"
			if dPoints <= 21:
				text += "\nDealer Wins!"
		self._textLabel.config(text = text)
		self._hitButton.config(state = "disabled")
		self._passButton.config(state = "disabled")

	def _newGame(self):
		"""Resets everything to how it was at the begining."""
		self._cardsD = []
		self._cardsP = []
		self.showCardsD()
		self.showCardsP()
		self._player = Player([self._deck.deal(), self._deck.deal()])
		self._dealer = Dealer([self._deck.deal(), self._deck.deal()])
		self._cardsD = self._dealer.getCardsD()
		self._cardsP = self._player.getCardsP()
		self._newButton.config(state = "disabled")
		
		self._textLabel.config(text = "You have " + str(self._player.getPoints()) + " points")
		
		self.showCardsD()
		self.showCardsP()
		
		self._hitButton.config(state = "normal")
		self._passButton.config(state = "normal")
	
def main():
	root = Tk()
	blackJack().mainloop()
	
main()	