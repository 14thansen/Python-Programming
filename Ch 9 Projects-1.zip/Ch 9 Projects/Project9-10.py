"""
The purpose of this program is to make a tic-tac-toe game. To play alone or with another player.
"""
from tkinter import *
from random import *

class TicTacToe(Frame):
	
	def __init__(self):
		Frame.__init__(self)
		self.master.title("Tic-Tac-Toe")
		self.grid()
		
		self.blankImage = PhotoImage(file = "pics/white.gif")
		self.blueImage = PhotoImage(file = "pics/blue.gif")
		self.oImage = PhotoImage(file = "pics/o.gif")
		self.xImage = PhotoImage(file = "pics/x.gif")
		
		self.xBoard = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
		self.oBoard = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
		self.board = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
		
		self.buttonImage = [[],[],[]]
		
		self.gamePane = Frame(self)
		self.gamePane.grid(row = 0, column = 0)
		for i in range(0, 3):
			for j in range(0, 3):
				self.buttonImage[i].append(Button(self.gamePane, width = 100, height = 100, 
						image = self.blueImage,
						command = lambda ii = i, jj = j: self._mark(ii, jj)))
				self.buttonImage[i][j].grid(row = i, column = j)
		"""
		self.buttonPane = Frame(self)
		self.var = IntVar()
		self.buttonPane.grid(row = 1, column = 0)
		self.rbEasy = Radiobutton(self.buttonPane, text = "Easy", variable = self.var, value = 1)
		self.rbEasy.pack(anchor = W, side = "left")
		self.rbEasy.grid(row = 0, column = 0)
		self.rbMed = Radiobutton(self.buttonPane, text = "Medium", variable = self.var, value = 2)
		self.rbMed.pack(anchor = W)
		self.rbMed.grid(row = 1, column = 0)
		self.rbHard = Radiobutton(self.buttonPane, text = "Hard", variable = self.var, value = 3)
		self.rbHard.pack(anchor = W)
		self.rbHard.grid(row = 2, column = 0)
		"""
		self.newButtonPane = Frame(self)
		self.newButtonPane.grid(row = 1, column = 0)
		self.newButton = Button(self.newButtonPane, text = "New Game", command = self.newGame)
		self.newButton.grid(row = 1, column = 0)
		self._textLabel = Label(self.newButtonPane, text = "Let's Play!")
		self._textLabel.grid(row = 0, column = 0)
		
	def _mark(self, r, c):
		if self.board[r][c] == 0:
			self.buttonImage[r][c].config(image = self.xImage)
			self.board[r][c] = 1
			self.xBoard[r][c] = 1
			winCount = self._win()
			if sum(self.board[0]+self.board[1]+self.board[2]) < 9:
				if winCount[0] != 3:
					rr = r
					cc = c
					while self.board[rr][cc] != 0:
						rr = randint(0,2)
						cc = randint(0,2)
					self.buttonImage[rr][cc].config(image = self.oImage)
					self.board[rr][cc] = 1
					self.oBoard[rr][cc] = 1
					winCount = self._win()
				if winCount[0] == 3 or winCount[1] == 3:
					for x in range(0,3):
						for y in range(0,3):
							self.buttonImage[x][y].config(state="disabled")
					if winCount[0] == 3:
						self._textLabel.config(text="You Win!")
					elif winCount[1] == 3:
						self._textLabel.config(text="You Lose!")
			else:
				if winCount[0] != 3 and winCount[1] != 3:
					self._textLabel.config(text="Cat's Game!")
				else:
					for x in range(0,3):
						for y in range(0,3):
							self.buttonImage[x][y].config(state="disabled")
					if winCount[0] == 3:
						self._textLabel.config(text="You Win!")
					elif winCount[1] == 3:
						self._textLabel.config(text="You Lose!")
	
	def _win(self):
		winCount = [0, 0]
		if winCount[0] != 3 and winCount[1] != 3:
			winCount[0] = self.xBoard[0][0] + self.xBoard[1][1] + self.xBoard[2][2]
			winCount[1] = self.oBoard[0][0] + self.oBoard[1][1] + self.oBoard[2][2]
		if winCount[0] != 3 and winCount[1] != 3:
			winCount[0] = self.xBoard[0][2] + self.xBoard[1][1] + self.xBoard[2][0]
			winCount[1] = self.oBoard[0][2] + self.oBoard[1][1] + self.oBoard[2][0]
		if winCount[0] != 3 and winCount[1] != 3:
			for i in range(0, 3):
				if winCount[0] != 3 and winCount[1] != 3:
					winCount = [0,0]
					winCount[0] = sum(self.xBoard[i])
					winCount[1] = sum(self.oBoard[i])
				else:
					break
		if winCount[0] != 3 and winCount[1] != 3:
			for j in range(0, 3):
				if winCount[0] != 3 and winCount[1] != 3:
					winCount = [0,0]
					winCount[0] = self.xBoard[0][j]+self.xBoard[1][j]+self.xBoard[2][j]
					winCount[1] = self.oBoard[0][j]+self.oBoard[1][j]+self.oBoard[2][j]
				else:
					break
		return winCount
		
	def newGame(self):
		self._textLabel.config(text = "Let's Play!")
		self.buttonImage = [[],[],[]]
		self.xBoard = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
		self.oBoard = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
		self.board = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
		for i in range(0, 3):
			for j in range(0, 3):
				self.buttonImage[i].append(Button(self.gamePane, width = 100, height = 100, 
						image = self.blueImage,
						command = lambda ii = i, jj = j: self._mark(ii, jj)))
				self.buttonImage[i][j].grid(row = i, column = j)

def main():
	root = Tk()
	#root.geometry("324x355+600+300")
	TicTacToe().mainloop()
main()