"""
The purpose of this program is to convert octadecimal numbers to decimal numbers and visaversa
"""

decimal = int(input("Enter a decimal integer: "))
if decimal == 0:
	print(0)
else:
	bString = ""
	while decimal > 0:
		remainder = decimal % 8
		decimal = decimal // 8
		bString = str(remainder) + bString
	print("The octal representation is", bString)
	print()
	
octal = input("Enter an octadecimal number: ")
decimal = 0
exponent = len(octal) - 1
for digit in octal:
	decimal = decimal + int(digit) * 8 ** exponent
	exponent = exponent - 1
print("The integer value is", decimal)