"""
the purpose of this program is to encode a word.
"""
# Plain text
text = input("Enter a single word: ")
text = text.lower()
code = ""
#Caesar Cipher
for letter in text:
	ordValue = ord(letter)
	cipherValue = ordValue + 1
	
	if cipherValue > ord('z'):
		cipherValue = ord('a') + 1 - (ord('z') - ordValue + 1)
	code += chr(cipherValue)

# Convert to binary
code = ' '.join(format(ord(x), 'b') for x in code)
codeList = code.split()

code = ""
shift = 1
for letter in codeList:
	letterCode = letter[shift:]
	for count in range(0, shift, 1):
		letterCode = letterCode + letter[count]
	code += letterCode + " "
codeList = code.split()

code = ""
for letter in codeList:
	code += ''.join(chr(int(letter, 2)))
	
print(code)