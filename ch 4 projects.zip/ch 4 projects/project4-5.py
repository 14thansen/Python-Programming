"""
The purpose of this program is to preform a bit shift operation.
"""
#Right Shift
bit = input("Enter a binary number: ")
shift = int(input("Spaces to shift to the right: "))
newBit = bit[-shift:]
for count in range(0, len(bit) - shift, 1):
	newBit = newBit + bit[count]
print("Shifted bit:", newBit)
print()

#left shift
bit = input("Enter a binary number: ")
shift = int(input("Spaces to shift to the left: "))
newBit = bit[shift:]
for count in range(0, shift, 1):
	newBit = newBit + bit[count]
print("Shifted bit:", newBit)