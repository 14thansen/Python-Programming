"""
the purpose of this program is to decode a word.
"""
# Plain text
text = input("Enter an encoded message: ")
code = ""

# Convert to binary
code = ' '.join(format(ord(x), 'b') for x in text)
codeList = code.split()

# bit shift
code = ""
shift = 1
for letter in codeList:
	letterCode = letter[-shift]
	for count in range(0, len(letter) - shift, 1):
		letterCode = letterCode + letter[count]
	code += letterCode + " "
codeList = code.split()

# to ascii
code = ""
for letter in codeList:
	code += ''.join(chr(int(letter, 2)))

#Caesar Cipher
text = ""
for letter in code:
	ordValue = ord(letter)
	cipherValue = ordValue - 1
	
	if cipherValue > ord('z'):
		cipherValue = ord('a') + 1 - (ord('z') - ordValue + 1)
	text += chr(cipherValue)
	
print(text)
