"""
The purpose of this program is to test Lee's algorithm.
"""

def printAll(seq):
	if seq:
		print(seq[0])
		printAll(seq[1:])

def main():
	nums = "123456789"
	printAll(nums)
	
main()

"""
The algorithm seems to run fine with various data types and sequences. The algorithm works by sending 
shortened sequence to the printAll statement and only prints the first line. One hidden cost is the 
sequence is actually split, rather than just printing the element as it appears, it is also cutting up 
the sequence.
"""