"""
The purpose of this program is to calculate and display the average of the numbers, initially stored in 
a text file.
"""
import random
from functools import reduce

def randNums():
	randTxt = open("randTxt.txt", 'w')
	for count in range(0, 50):
		num = random.randint(1, 100)
		randTxt.write(str(num) + "\n")
	
	randTxt.close()

def add(x, y): return x + y

def average(nums):
	intNums = list(map(int, nums))
	print(reduce(add, intNums)/len(intNums))
	
def main():
	randNums()
	randTxtR = open("randTxt.txt", 'r')
	nums = randTxtR.read().split()
	average(nums)

main() 