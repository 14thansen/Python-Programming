"""
The purpose of this program is to show that gambling makes no sence
"""
import random


pot = float(input("How much money do you have: $"))
count = 0
high = pot
while pot > 0:
	num1 = random.randint(1, 6)
	num2 = random.randint(1, 6)
	if num1 + num2 == 7:
		pot += 4
	else:
		pot -= 1
	#end if
	if pot > high:
		high = pot
	count += 1
#end while
print("It took you", count, "turns to lose all your money.")
print("The most amount of money you had was $", high, "before you went broke.")
print("You're not that lucky, don't gamble")