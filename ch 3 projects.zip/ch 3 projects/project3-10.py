"""
The purpose of this program is to display a table to show how long you will be paying for something you bought at tidBit
"""

price = int(input("Purchase price: $"))
month = 0
downpayment = price * .10
balance = price - downpayment
rate = .12

print("Downpayment: $", downpayment)
print("%5s%9s%15s%16s%17s%20s" % 
	("Month", "Balance", "Interest Due", "Principle Due", "Total Payment", "Remaining Balance"))
while balance > 0:
	month += 1
	interest = balance * rate / 12
	principle = price * .05
	total = interest + principle
	
	print("%5d%3s%-9.2f%3s%-13.2f%4s%-13.2f%4s%-13.2f%4s%-13.2f" %
		(month, "$", balance, "$", interest, "$", principle, "$", total, "$", balance - total))
	balance = balance - total

	
