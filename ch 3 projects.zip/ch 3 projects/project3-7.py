"""
The purpose of this program is to create a table that displays the salaries of teachers up to their ten-year
"""

salary = float(input("Starting salary: $"))
increase = float(input("Yearly percent increase (Decimal format): "))
years = int(input("How many years: "))
print("%4s%10s" % ("Year", "Salary"))
for year in range(1, years + 1, 1):
	print("%4d%5s%5.2f" % (year, "$", salary))
	salary = salary + (salary * increase)