"""
The purpose of this program is to organize the happenings in a library.
"""
import pickle

class Book(object):
	"""This class represents an individual book."""
	
	def __init__(self, title, author):
		self._title = title
		self._author = author
		self._patron = None
		self._waitList = []
		
	def __str__(self):
		info = "Title: " + self._title + "\n"
		info += "Author: " + self._author + "\n"
		info += "Checked out to: " + str(self._patron) + "\n"
		info += "Waiting: " + str(self._waitList) + "\n"
		return info
		
	def getTitle(self):
		return self._title
	def getAuthor(self):
		return self._author
	def getPatron(self):
		return self._patron
	def getWaitList(self):
		return '\n'.join(map(str, self._waitList.values()))
	
	def addPatrons(self, name):
		if self._patron == None:
			self._patron = name
			print("\"", self._title, "\" checked out to", self._patron)
		else:
			self.addWaitList(name)
			print("Added to wait list for \"", self._title, "\"")
			
	def removePatron(self):
		print("\"", self._title, "\", Checked in")
		if self._waitList != None:
			self._patron = self._waitList[0]
			print("\"", self._title, "\" checked out to", self._patron)
			del self._waitList[0]
		else:
			self._patron = None
	
	def addWaitList(self, name):
		self._waitList.append(name)
		
class Patron(object):
	"""This class represents an individual patron."""
	def __init__(self, name):
		self._name = name
		self._books = []
		
	def __str__(self):
		info = "Patron: " + self._name + "\n"
		info += "Books: " + str(self._books) + "\n"
		return info
		
	def getName(self):
		return self._name
		
	def getBooks(self):
		return self._books
		
	def addToBooks(self, book):
		self._books.append(book)
		 				
class Library(object):
	"""This class manages the books and the patrons."""
	
	def __init__(self, patronFile = None, bookFile = None):
		self._people = {}
		self._books = {}
		self._patronFile = patronFile
		self._bookFile = bookFile
		if patronFile != None:
			patronObj = open(patronFile, 'rb')
			while True:
				try:
					person = pickle.load(patronObj)
					self.addPatron(person)
				except EOFError:
					patronObj.close()
					break
		if bookFile != None:
			bookObj = open(bookFile, 'rb')
			while True:
				try:
					book = pickle.load(bookObj)
					self.addBook(book)
				except EOFError:
					patronObj.close()
					break
	
	def addPatron(self, person):
		if person.getName() in self._people:
			print("Person already in system")
		else:
			self._people[person.getName()] = person
		
	def addBook(self, book):
		if book.getTitle() in self._books:
			print("Book already exists")
		else:
			#print('"', book.getTitle(), '" added to library')
			self._books[book.getTitle()] = book
			
	def checkout(self, book, name):
		
		if name in self._people:
			if book in self._books:
				if len(self._people[name].getBooks()) < 3:
					self._books[book].addPatrons(name)
					self._people[name].addToBooks(book)
				else:
					print("You have too many books checked out.")
			else:
				print("Book does not exsist")
				print(self._str_books())
		else:
			print("Patron does not exsist")
			print("Exsisting patrons:")
			print(self._str_patrons())
	
	def checkin(self, book):
		if book in self._books:
			self._books[book].removePatron()
		else:
			print("Book does not exsist")
	
	def removePatron(self, name):
		self._people.pop(name, None)
	def removeBook(self, title):
		self._books.pop(title, None)
		
		
	def getPatron(self, name):
		return self._people.get(name, None)
	def getBook(self, title):
		return self._books.get(title, None)
		
		
	def _str_patrons(self):
		return '\n'.join(map(str, self._people.values()))
	def _str_books(self):
		return '\n'.join(map(str, self._books.values()))
		
		
	def save(self, patronFile = None, bookFile = None):
		if patronFile != None:
			self._patronFile = patronFile
		elif self._patronFile == None:
			return
		patronObj = open(self._patronFile, 'wb')
		for person in self._people.values():
			pickle.dump(person, patronObj)
		patronObj.close()
		
		if bookFile != None:
			self._bookFile = bookFile
		elif self._bookFile == None:
			return
		bookObj = open(self._bookFile, 'wb')
		for book in self._books.values():
			pickle.dump(book, bookObj)
		bookObj.close()
		
class Manager(object):
	"""This class provides a menu driven command processor for managing the library."""
	
	def __init__(self, library = Library()):
		self._library = library
		self._methods = {}
		self._methods["1"] = self._getPatrons
		self._methods["2"] = self._getBooks
		self._methods["3"] = self._addPatrons
		self._methods["4"] = self._addBooks
		self._methods["5"] = self._removePatrons
		self._methods["6"] = self._removeBooks
		
	def run(self):
		while True:
			print("\n1  View patrons")
			print("2  View Books")
			print("3  Add patrons")
			print("4  Add books")
			print("5  Remove patrons")
			print("6  Remove books")
			print("7  Quit")
			number = input("Enter a number: ")
			print()
			theMethod = self._methods.get(number, None)
			if theMethod == None and number != "7":
				print("Unrecognized number")
			elif number == "7":
				self._library.save("libraryP.txt", "libraryB.txt")
				print("Have a nice day!\n")
				break
			else:
				theMethod()
				
	def _getPatrons(self):
		print(self._library._str_patrons())
	def _getBooks(self):
		print(self._library._str_books())
	
	def _addPatrons(self):
		name = input("Name: ")
		self._library.addPatron(Patron(name))
		
	def _addBooks(self):
		title = input("Title: ")
		author = input("Author: ")
		patron = input("Patron: ")
		if len(patron) == 0:
			patron = None
		self._library.addBook(Book(title, author, patron))
		
	def _removePatrons(self):
		name = input("Name: ")
		self._library.removePatron(name)
	def _removeBooks(self):
		title = input("Title: ")
		self._library.removeBook(title)

def addStuff():
	library = Library()
	library.addPatron(Patron("Thayne Hansen"))
	library.addPatron(Patron("Merrilee Williams"))
	library.addPatron(Patron("Jack Skeleton"))
	library.addPatron(Patron("Santa Clause"))
	library.addBook(Book("Of Mice and Men", "John Steinbeck"))
	library.addBook(Book("The Great Gatsby", "F. Scott Fitzgerald"))
	library.addBook(Book("The Lord of the Rings", "J. R. R. Tolkien"))
	library.addBook(Book("The Giver", "Lois Lowry"))
		
	library.save("libraryP.txt", "libraryB.txt")
	
def main(this = 1):
	if this == 0:
		addStuff()
	library = Library("libraryP.txt", "libraryB.txt")
	while True:
		print("\n1  Manage library")
		print("2  Check out a book")
		print("3  Return a book")
		print("4  Quit")
		menu = int(input("Enter a number: "))
		if menu == 1:
			Manager(library).run()
		elif menu == 2:
			book = input("Book title: ")
			patron = input("Check out to: ")
			library.checkout(book, patron)
		elif menu == 3:
			book = input("Book title: ")
			library.checkin(book)
		elif menu == 4:
			break
		else:
			print("Number not recognized")

main(0)