"""
This program defines the bank classes
"""
import pickle

class bankAccount(object):
	"""This class represents an idividual account"""
	
	def __init__(self, name, number, pin = "0000", balance = 0.0):
		self._name = name
		self._number = number
		self._pin = pin
		self._balance = balance 
		
	def __str__(self):
		result =  'Name:      ' + self._name + '\n' 
		result += 'Account #: ' + self._number + '\n'
		result += 'PIN:       ' + self._pin + '\n' 
		result += 'Balance:   ' + str(self._balance) + '\n'
		return result
	
	def getName(self):
		return self._name
		
	def setName(self, newName):
		self._name = newName
		
	def getNumber(self):
		return self._number
		
	def setNumber(self, newNumber):
		self._number = newNumber

	def getPin(self):
		return self._pin
		
	def setPin(self, newPin):
		self._pin = newPin
		
	def getBalance(self):
		return self._balance

	def setBalance(self, amount):
		"""Allows owner to manually change balance."""
		self._balance = amount
		return self._balance
		
class Bank(object):
	"""This class gives access to all of the accounts"""
	
	def __init__(self, fileName = None):
		self._accounts = {}
		self._fileName = fileName
		if fileName != None:
			fileObj = open(fileName, 'rb')
			while True:
				try:
					account = pickle.load(fileObj)
					self.add(account)
				except EOFError:
					fileObj.close()
					break
		
	def add(self, account):
		self._accounts[account.getNumber()] = account
		
	def remove(self, number):
		self._accounts.pop(number, None)
	
	def get(self, number):
		return self._accounts.get(number, None)
		
	def __str__(self):
		return '\n'.join(map(str, self._accounts.values()))
			
	def save(self, fileName = None):
		if fileName != None:
			self._fileName = fileName
		elif self._fileName == None:
			return
		fileObj = open(self._fileName, 'wb')
		for account in self._accounts.values():
			pickle.dump(account, fileObj)
		fileObj.close()
"""
def main():
	bank = Bank()
	bank.add(bankAccount("Wilma", "1", "1111", 1000.00))
	bank.add(bankAccount("Fred", "2", "1234", 2000.00))
	bank.add(bankAccount("Thayne", "3", "2468", 3000.00))
	bank.add(bankAccount("George", "4", "3691", 4000.00))
	bank.add(bankAccount("Devora", "5", "4812", 5000.00))
	bank.save("Bank.txt")
	
	
main()
"""