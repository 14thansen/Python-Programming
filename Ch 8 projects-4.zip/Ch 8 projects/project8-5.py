"""
The purpose of this program is to allow a bank manager to manipulate accounts at a bank.
"""

from myBank import Bank, bankAccount

class manage(object):
	"""This class allows you to manipulate accounts."""
	def __init__(self, bank):
		self._account = None
		self._bank = bank
		self._methods = {}
		self._methods["1"] = self._getInfo
		self._methods["2"] = self._setBalance
		self._methods["3"] = self._editAccount
		self._methods["4"] = self._quit
		
	def run(self):
		"""Select account to edit."""
		while True:
			number = input("\nEnter account number ('done' to exit): ")
			if number == "done":
				break
			self._account = self._bank.get(number)
			self._processAccount()	
				
	def _processAccount(self):
		"""A menu of options for the manager to use."""
		while True:
			print("\n1  View client information")
			print("2  Change the balance")
			print("3  Change client's account information")
			print("4  Quit")
			number = input("Enter a number: ")
			print()
			theMethod = self._methods.get(number, None)
			if theMethod == None:
				print("Unrecognized number")
			else:
				theMethod()
				if self._account == None:
					break			
			
	def _getInfo(self):
		print(self._account)
		
	def _setBalance(self):
		amount = float(input("Enter the new balance amount: "))
		self._account.setBalance(amount)
		
	def _editAccount(self):
		while True:
			print("1  Change account name")
			print("2  Change account number")
			print("3  Change PIN")
			print("4  Quit")
			number = int(input("Enter a number: "))
			if number == 1:
				self._editName()
			elif number == 2:
				self._editNumber()
			elif number == 3:
				self._editPin()
			elif number == 4:
				break
	
	def _editName(self):
		name = input("Enter new name: ")
		self._account.setName(name)
	
	def _editNumber(self):
		number = input("Enter new account number: ")
		self._account.setNumber(number)
		
	def _editPin(self):
		pin = input("Enter new PIN: ")
		self._account.setPin(pin)
		
	def _quit(self):
		self._bank.save("Bank.txt")
		self._account = None
		print("Have a nice day!")
		main()
		
def main():
	bank = Bank("Bank.txt")
	while True:
		print("1  Edit an account")
		print("2  Add an account")
		print("3  Remove an account")
		print("4  View all accounts")
		print("5  Quit")
		
		menu = int(input("Enter a number: "))
		if menu == 1:
			ans = False
			manage(Bank("Bank.txt")).run()
		elif menu == 2:
			name = input("\nNew account name: ")
			number = input("Account number: ")
			pin = input("PIN number: ")
			balance = int(input("Starting balance: $"))
			bank.add(bankAccount(name, number, pin, balance))
		elif menu == 3:
			number = input("\nAccount number to remove: ")
			bank.remove(number)
		elif menu == 4:
			print(bank)
		else:
			break

main()
			
			
		