"""
The purpose of this program is to organize the happenings in a library.
"""
import pickle

class Book(object):
	"""This class represents an individual book."""
	
	def __init__(self, title, author, patron = None, waitList = None):
		self._title = title
		self._author = author
		self._patron = patron
		self._waitList = waitList
		
	def __str__(self):
		info = "Title: " + self._title + "\n"
		info += "Author: " += self._author + "\n"
		info += "Checked out to: " + str(self._patron) + "\n"
		info += "Waiting: " + str(self._waitList) + "\n"
		return info
	
	