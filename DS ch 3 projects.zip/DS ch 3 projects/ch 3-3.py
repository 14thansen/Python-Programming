"""
This program works like the pow function.
"""

def expo(num, exp):
	count = 1
	newNum = num
	while count < exp:
		num *= newNum
		count += 1
	return num
	
def main():
	num = int(input("Base integer: "))
	exp = int(input("Exponent (Positive numbers only): "))
	print()
	print(num, "^", exp, "=", expo(num, exp))
main()

"""
Big O notation:
	worst, best, and average cases are all O(n)
"""