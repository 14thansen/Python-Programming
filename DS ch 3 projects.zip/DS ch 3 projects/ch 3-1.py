"""
This program is a modified sequential search algorithm.
"""

def sequentialSearchMod(lyst, num):
	pos = 0
	while pos < len(lyst):
		if num < lyst[pos]:
			return pos, lyst[pos]
		pos += 1
	return -1
	
def main():
	start = int(input("Start list with what number? "))
	end = int(input("End list with what number? " ))
	count = int(input("Count by what? "))
	num = int(input("Find a number in the list just higher than: "))
	lyst = []
	for i in range(start, end, count):
		lyst.append(i)
	print()
	print(lyst)
	pos = sequentialSearchMod(lyst, num)
	print("We found (", pos[1], ") in position", pos[0])
	
main()

"""
Big O notation:
	best case: the target is in the 1 position... O(1)
	worst case: the target does not exsist or is in the last position... O(n)
	average case: (n+1)/2 or... O(n)
"""