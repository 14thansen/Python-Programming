"""
A modified selection sort algorithm.
"""
def swap(lyst, i, j):
	temp = lyst[i]
	lyst[i] = lyst[j]
	lyst[j] = temp

def selectionSortMod(lyst, flow = True):
	if flow:
		i = 0
		while i < len(lyst) - 1:
			minIndex = i
			j = i + 1
			while j < len(lyst):
				if lyst[j] < lyst[minIndex]:
					minIndex = j
				j += 1
			if minIndex != i:
				swap(lyst, minIndex, i)
			i += 1
	else:
		i = 0
		while i < len(lyst) - 1:
			maxIndex = i
			j = i + 1
			while j < len(lyst):
				if lyst[j] > lyst[maxIndex]:
					maxIndex = j
				j += 1
			if maxIndex != i:
				swap(lyst, maxIndex, i)
			i += 1
	return lyst
			
import random
def main():
	lyst = []
	for num in range(25):
		lyst.append(random.randint(0, 25))
	print(lyst)
	print(selectionSortMod(lyst))
	print(selectionSortMod(lyst, False))
	
main()

"""
Big O notation:
	The best, worst, and average cases would be the same because even if the list were already sorted there is no check set up to see when it is sorted and would continue to complete the algorithm until the end of the list so... O(n^2)
"""