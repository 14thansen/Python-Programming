"""
the purpose of this program is to sort a text file into alphabetical
order.
"""

wordtxt = open("wordList.txt", 'w')

def main():
	print("Enter words, one at a time, enter a blank line to finish")
	words = input(">>")
	while len(words) > 0:
		words.lower()
		wordtxt.write(words + "\n")
		words = input(">>")

	wordtxt.close()
	print("word list in alphabetical order")
	wordtxtR = open("wordList.txt", 'r')
	wordList = wordtxtR.read().split()
	wordList.sort()
	for word in wordList:
		print(word)
		print()
            
	wordtxtR.close()

main()
