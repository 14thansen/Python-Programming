"""
The program generates random sentances.
"""

import random

fNouns = open("nouns.txt", 'r').read().split()
fVerbs = open("verbs.txt", 'r').read().split()
fPrepositions = open("prepositions.txt", 'r').read().split()
fArticles = open("articles.txt", 'r').read().split()

	
def sentence():
	return random.choice(fNouns) + " " + verbPhrase()

def nounPhrase():
	return random.choice(fArticles) + " " + random.choice(fNouns)
	
def verbPhrase():
	return random.choice(fVerbs) + " " + nounPhrase() + " " + prepositionalPhrase()
	
def prepositionalPhrase():
	return random.choice(fPrepositions) + " " + nounPhrase()
	
def main():
	number = int(input("Enter the number of sentences: "))
	for count in range(number):
		print(sentence())
		
main()