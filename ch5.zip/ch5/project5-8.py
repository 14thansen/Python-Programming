"""
The purpose of this program is to count the words in a text file. In this program I used my java
final project proposal as an example.
"""
from collections import Counter
import collections

wordtxt = open("javaFinal.txt", 'r')

def main():
	wordList = wordtxt.read().split()
	words = []
	for word in wordList:
		words.append(word.lower())
	
	for word in range(0, len(words) - 1):
		for char in ".,;!":
			words[word] = words[word].replace(char, "")
			
	wordsDict = dict(Counter(words))
	wordsDict = collections.OrderedDict(sorted(wordsDict.items()))
	wordList = list(wordsDict.keys())
	nums = list(wordsDict.values())
	
	for word in range(0, len(wordList)):
		print(wordList[word], ":", nums[word])
            
	wordtxt.close()

main()