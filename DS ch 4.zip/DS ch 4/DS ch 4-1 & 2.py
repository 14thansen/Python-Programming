"""
A modified version of the arrays class found in the book. 
This class allows you to get the logical size of the array.
"""

class Array(object):
    """Represents an array."""

    def __init__(self, capacity, fillValue = None):
        """Capacity is the static size of the array.
        fillValue is placed at each position."""
        self._items = list()
        self._logicalSize = 0
        for count in range(capacity):
            self._items.append(fillValue)
            if fillValue != None:
                self._logicalSize += 1

    def __len__(self):
        """-> The capacity of the array."""
        return len(self._items)

    def __str__(self):
        """-> The string representation of the array."""
        return str(self._items)

    def __iter__(self):
        """Supports iteration over a view of an array."""
        return iter(self._items)

    def __getitem__(self, index):
        """Subscript operator for access at index."""
        if index >= 0 and index <= size():
            return self._items[index]
        else:
            raise IndexError("Index is out of bounds")

    def __setitem__(self, index, newItem):
        """Subscript operator for replacement at index."""
        if index >= 0 and index <= size():
            self._items[index] = newItem
        else:
            raise IndexError("Index is out of bounds")
        
    def size(self):
        return self._logicalSize