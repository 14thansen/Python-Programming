"""
Tests the node class and its capabilities.
"""
from node import Node

def length(n):
	probe = n
	count = 0
	while probe != None:
		probe = probe.next
		count += 1
	return count
	
def insert(newItem, index, n):
	if n == None or index <= 0:
		n = Node(newItem, n)
		return n
	else:
		probe = n
		while index > 1 and probe.next != None:
			probe = probe.next
			index -= 1
		probe.next = Node(newItem, probe.next)
		return n
			
def main():
	head = None
	
	#create Node
	for count in range(1, 6):
		head = Node(count, head)
	probe = head
		
	print("Original: ")
	while probe != None:
		print(probe.data)
		probe = probe.next
	probe = head	
	print("length:", length(probe))
	
	head = insert('X', 3, head)
	probe = head
	print("\nNew: ")
	while probe != None:
		print(probe.data)
		probe = probe.next
	print("New length:", length(head))
		
	
main()