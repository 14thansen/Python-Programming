class ChatRecord(object):
	def __init__(self, name)