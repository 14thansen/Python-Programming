"""
This program acts as an online phonebook.
"""

from socket import *
from codecs import decode
from threading import Thread
from phonebookRecord import RecordInfo

class ClientHandler(Thread):
	def __init__(self, client, record):
		Thread.__init__(self)
		self._client = client
		self._record = record
		
	def run(self):
		self._client.send(bytes('Welcome to your digital phonebook!', CODE))
		self._choice = decode(self._client.recv(BUFSIZE), CODE)
		print(self._choice)
		while True:
			if not self._choice:
				print('Client disconnected')
				self._client.close()
				break
			else:
				if self._choice == "1":
					self._client.send(bytes(str(self._record), CODE))
					break
				elif self._choice == "2":
					self._client.send(bytes('First Name: ', CODE))
					self._name = decode(self._client.recv(BUFSIZE), CODE)
					self.book = open('phonebook.txt', 'r')
					for line in self.book:
						if self._name.find(line, 0, len(line)):
							self._client.send(bytes(line, CODE))
					self.book.close()
				elif self._choice == "3":
					self._client.send(bytes('First Name: ', CODE))
					self._name = decode(self._client.recv(BUFSIZE), CODE)
					self._client.send(bytes('Phone Number: ', CODE))
					self._number = decode(self._client.recv(BUFSIZE), CODE)
					self._number = self._number.strip().replace(" ", "")
					self._name = self._name + " " + self._number + "\n"
					self._record.add(self._name)
					self._client.send(bytes('Person added', CODE))
			
HOST = 'localhost'
PORT = 7001
ADDRESS = (HOST, PORT)
BUFSIZE = 1024
CODE = 'ascii'
record = RecordInfo()

server = socket(AF_INET, SOCK_STREAM)
server.bind(ADDRESS)
server.listen(5)

while True:
	print('Waiting for connection ...')
	client, address = server.accept()
	print('... connected from:', address)
	handler = ClientHandler(client, record)
	handler.start()