"""
This program records everything to the phonebook.
"""
class RecordInfo(object):
	def __init__(self):
		self.data = " "
		
	def add(self, s):
		self.dataW = open("phonebook.txt", 'a')
		self.dataW.write(s)
		self.dataW.close()
		
	def __str__(self):
		self.dataR = open("phonebook.txt", 'r')
		self.data = self.dataR.read()
		if len(self.data) == 0:
			return 'No numbers saved yet'
		else:
			return self.data
		self.dataR.close()