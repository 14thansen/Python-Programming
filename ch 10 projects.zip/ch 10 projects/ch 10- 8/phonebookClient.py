"""
This program is a client to the phonebook.
"""

from socket import *
from codecs import decode

HOST = 'localhost'
PORT = 7001
BUFSIZE = 1024
ADDRESS = (HOST, PORT)
CODE = 'ascii'
server = socket(AF_INET, SOCK_STREAM)
server.connect(ADDRESS)

print(decode(server.recv(BUFSIZE), CODE))

while True:
	print("\nWhat would you like to do?")
	print("1: View phonebook records")
	print("2: Search for a name")
	print("3: Add name")
	choice = input("Your choice: ")
	server.send(bytes(choice, CODE))
	if not choice:
		print('Server disconnected')
		break
	else:
		if choice == "1":
			print()
			print(decode(server.recv(BUFSIZE), CODE))
			break
		elif choice == "2":
			name = input(decode(server.recv(BUFSIZE), CODE))
			server.send(bytes(name, CODE))
			print(decode(server.recv(BUFSIZE), CODE))
			break
		elif choice == "3":
			name = input(decode(server.recv(BUFSIZE), CODE))
			server.send(bytes(name, CODE))
			number = input(decode(server.recv(BUFSIZE), CODE))
			server.send(bytes(name, CODE))
		else:
			break

server.close()
		