"""
File: doctorclient.py

Client for a therapy session.
"""

from socket import *
from codecs import decode
from doctor import Doctor

HOST = 'localhost'
PORT = 6000
BUFSIZE = 1024
ADDRESS = (HOST, PORT)
CODE = 'ascii'

server = socket(AF_INET, SOCK_STREAM)
server.connect(ADDRESS)
name = input("Enter your name: ")
server.send(bytes(name, CODE))

print(decode(server.recv(BUFSIZE), CODE))

while True:
	message = input('> ')
	if not message:
		print(Doctor().farewell())
		break
	server.send(bytes(message, CODE))
	reply = decode(server.recv(BUFSIZE), CODE)
	if not reply:
		print("Server disconnected")
		break
	print(reply)
server.close()
