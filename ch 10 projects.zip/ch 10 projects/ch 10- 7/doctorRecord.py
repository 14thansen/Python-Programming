"""
This class keeps track of the conversations had with the doctor.
"""
import random

class ChatRecord(object):
	def __init__(self, name):
		self._name = name
		self._file = name + ".txt"
	
	def add(self, s):
		self.dataW = open(self._file, 'a')
		self.dataW.write(s + '\n')
		self.dataW.close()
			
	def getOldIssue(self):
		self.dataR = open(self._file, 'r')
		self.lines = self.dataR.readlines()
		self.line = random.choice(self.lines)
		self.line = self.line.replace("\n", "")
		return self.line
		self.dataR.close()