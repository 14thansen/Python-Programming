"""
File: picception.py

Changes the size of the images and organizes them.
"""

from tkinter import *
from images import Image



class picception(Frame):
	
	def __init__(self, minipics, bigpic):
		"""Collects information and variables needed to run program."""
		self._bigpic = Image(bigpic)
		self._bigpic.draw()
		self._minipics = []
		for pic in minipics:
			self._minipics.append(Image(pic))
		self._widthB = 0
		self._heightB = 0
		self._widthS = 0 
		self._heightS = 0
		self.__getSize()
		for pic in range(len(self._minipics)):
			self._minipics[pic] = self.resize(self._minipics[pic])
		
		
	def __getSize(self):
		"""Determins the size of the small images."""
		self._widthB = self._bigpic.getWidth()
		self._heightB = self._bigpic.getHeight()
		print(self._widthB, self._heightB)
		self._widthS = self._widthB / 32
		self._heightS = self._heightB / 32
		if self._widthS < 1: self._widthS = 1
		if self._heightS < 1: self._heightS = 1
		
	def resize(self, image):
		"""Builds and returns a new image,
		the size determined by __getSize."""
		width = image.getWidth()
		height = image.getHeight()
		factorW = width / self._widthS
		factorH = height / self._heightS
		self._widthS = int(width // factorW)
		self._heightS = int(height // factorH)
		print(self._widthS, self._heightS)
		new = Image(self._widthS, self._heightS)
		oldY = 0
		newY = 0
		while oldY < height - int(factorH):
			oldX = 0
			newX = 0
			while oldX < width - int(factorW):
				oldP = image.getPixel(oldX, oldY)
				new.setPixel(newX, newY, oldP)
				oldX += int(factorW)
				newX += 1
			oldY += int(factorH)
			newY += 1
		return new
		
	def create(self):
		"""Places images to create the larger image."""
		newImage = Image(self._widthB, self._heightB)
		for pixelY in range(0, self._heightB, self._heightS):
			for pixelX in range(0, self._widthB, self._widthS):
				(r, g, b) = self.__getColor(self._bigpic, pixelX, pixelY, self._widthS, self._heightS)
				for y in range(pixelY, pixelY + self._heightS):
					for x in range(pixelX, pixelX + self._widthS):
						newImage.setPixel(x, y, (r, g, b))
		newImage.draw()
			
	def __getColor(self, pic, startx = None, starty = None, width = None, height = None):
		if width != None:
			rBucket = 0
			gBucket = 0
			bBucket = 0
			pixelCount = 0
			for y in range(starty, starty + height):
				if y >= self._heightB: break
				for x in range(startx, startx + width):
					if x >= self._widthB: break
					r, g, b = pic.getPixel(x, y)
					rBucket += r
					gBucket += g
					bBucket += b
					pixelCount += 1
		print(rBucket//pixelCount, gBucket//pixelCount, bBucket//pixelCount)
		return (rBucket//pixelCount, gBucket//pixelCount, bBucket//pixelCount)
		
	#def __setColor(self, pic):
		
									
def main():
	minipics = ["/Users/student/Downloads/pic-ception/test folder/bear.gif",
				
				"/Users/student/Downloads/pic-ception/test folder/bubble.gif",
				"/Users/student/Downloads/pic-ception/test folder/bush.gif",
				"/Users/student/Downloads/pic-ception/test folder/random_detail.gif",
				"/Users/student/Downloads/pic-ception/test folder/Random_picture_of_shark.gif",
				"/Users/student/Downloads/pic-ception/test folder/weird lines.gif",
				"/Users/student/Downloads/pic-ception/test folder/weird nails.gif",
				"/Users/student/Downloads/pic-ception/test folder/wood animals.gif"]
	bigpic = "/Users/student/Downloads/pic-ception/test folder/brocoli.gif"
	
	picception(minipics, bigpic).create()
	
main()
		
		
		
		
		
		
		
		
		
		
		
		
		