"""
File: picGUI.py

A graphical layout for my pic-ception program. 
Gives the user a place to download files, and 
choose several other options for your collage.
"""

from tkinter import *
from tkinter import filedialog
import os

class picGUI(Frame):
	
	def __init__(self):
		"""Sets up the frame for the pic-ception program"""
		# Create the main frame
		Frame.__init__(self)
		self.master.title("Pic-Ception")
		self.grid(sticky = W+E+N+S)
		
		# Create a space for the instructions to appear
		self._instructionPane = Frame(self)
		self._instructionPane.grid(row = 0, column = 0)
		self.instructiontxt = 	"		  Welcome to 'Pic-Ception'!		\n"
		self.instructiontxt +=	"'Pic-Ception' is a collage generator that allows the user to put a lot of tiny pictures together to create one giant picture automatically. It is basically the greatest thing you've ever heard of, I know.\n"
		self.instructiontxt +=	"			Instructions:			\n"
		self.instructiontxt +=	"1. Choose the files that you wish to add as your small photos and place them in a single folder. The more photos you have the better your final product will look.\n"
		self.instructiontxt +=	"2. Convert those files to a .gif format (that is the only format the program will accept at this time). I recommend using this website (https://www.iloveimg.com/jpg-to-image/jpg-to-gif) because they allow you to convert and download multiple images at a time, but you may use any program that you like.\n"
		self.instructiontxt +=	"3. Choose the image that you would like your other images to create and convert that into a .gif file as well.\n"
		self.instructiontxt +=	"4. Upload your now converted images by clicking the appropriate browse buttons.\n"
		self._instructionLbl = Text(self._instructionPane, width = 65, height = 18, wrap = WORD)
		self._instructionLbl.insert("1.0", self.instructiontxt)
		self._instructionLbl.config(state=DISABLED)
		self._instructionLbl.grid(row = 0, column = 0)
		
		# Create the list box to show which files are being used
		self._listPane = Frame(self)
		self._listPane.grid(row = 1, column = 0)
		self._yScroll = Scrollbar(self._listPane, orient = VERTICAL)
		self._yScroll.grid(row = 0, column = 1, sticky = N+S, padx = (0, 5), pady = 5)
		self._xScroll = Scrollbar(self._listPane, orient = HORIZONTAL)
		self._xScroll.grid(row = 1, column = 0, sticky = E+W, pady = (0, 5), padx = 5)
		self._theList = Listbox(self._listPane,
								width = 50,
								height = 10,
								selectmode = BROWSE,
								yscrollcommand = self._yScroll.set,
								xscrollcommand = self._xScroll.set)
		self._theList.grid(row = 0, column = 0, sticky = E+W, pady = 5, padx = 5,
							ipady = 5, ipadx = 5)
		self._theList.insert(END, "Mini Images go here")
		self._yScroll["command"] = self._theList.yview
		self._xScroll["command"] = self._theList.xview
		
		# Create buttons for browsing and text box for main photo
		self._browsePane = Frame(self)
		self._browsePane.grid(row = 2, column = 0)
		self._miniBt = Button(self._browsePane, text = "Mini Images", command = self._browseM)
		self._miniBt.grid(row = 0, column = 3)
		self._bigBt = Button(self._browsePane, text = "Big Image", command = self._browseB)
		self._bigBt.grid(row = 0, column = 2)
		self._browseTxt = Text(self._browsePane, width = 7, height = 1)
		self._browseTxt.insert("1.0", "Browse:")
		self._browseTxt.config(state = DISABLED)
		self._browseTxt.grid(row = 0, column = 1)
		self._inputVar = StringVar()
		self._bigList = Entry(self._browsePane,
							  textvariable = self._inputVar,
							  width = 25)
		self._bigList.insert(0, "Big Image goes here")
		self._bigList.grid(row = 0, column = 0, pady = 5, padx = 5)
		
		self._nextBt = Button(self, text = "Next >>", width = 50)#, command = self._next)
		self._nextBt.grid(row = 3, column = 0)
		
		#Variables to save file names
		self._miniPics = []
		self._bigPic = ""	
		
		
	def _browseM(self):
		"""Opens the browse frame to find the mini photos and saves file names to a list."""
		tempdir = filedialog.askopenfilenames(initialdir="/", title='Please files', 
								filetypes = (("gif files", "*.gif"), ("all files", "*.*")))
		self._theList.delete(0)
		for item in tempdir:
			self._theList.insert(END, item)
			self._miniPics.append(item)
			
	def _browseB(self):
		"""Opens the brose frame to find the large photo and saves file name."""
		self._bigPic = filedialog.askopenfilename(initialdir="/", title='Please files', 
								filetypes = (("gif files", "*.gif"), ("all files", "*.*")))
		self._bigList.delete(0, 100)
		self._bigList.insert(0, self._bigPic)
		
def main():
	picGUI().mainloop()
	
main()	
		
		
		
		
		
		
		