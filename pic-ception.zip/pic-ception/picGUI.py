"""
File: picGUI.py

A graphical layout for my pic-ception program. 
Gives the user a place to download files, and 
choose several other options for your collage.
"""

from tkinter import *
import os

class picGUI(Frame):
	
	def __init__(self):
		# Create the main frame
		Frame.__init__(self)
		self.master.title("Pic-Ception")
		self.grid(sticky = W+E+N+S)
		
		# Create the list box to show which files are being downloaded
		self._listPane = Frame(self)
		self._listPane.grid(row = 0, column = 0, sticky = N)
		self._yScroll = Scrollbar(self._listPane, orient = VERTICAL)
		self._yScroll.grid(row = 0, column = 0, sticky = N+S)
		self._theList = Listbox(self._listPane,
								width = 15,
								height = 10,
								selectmode = BROWSE,
								yscrollcommand = self._yScroll.set)
		self._theList.grid(row = 0, column = 0, sticky = E+W)
		self._yScroll["command"] = self._theList.yview
		self._BrowseBt = Button(self._listPane, text = "Browse", command =)	