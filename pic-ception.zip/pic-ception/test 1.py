from tkinter import filedialog
#import tkFileDialog
import os

#root = Tk()
#root.withdraw() #use to hide tkinter window

currdir = os.getcwd()
tempdir = filedialog.askdirectory(initialdir=currdir, title='Please select a directory')
if len(tempdir) > 0:
	print("You chose %s" % tempdir)