"""
Program: project2-6
Author: Thayne Hansen

The purpose of this program is to calculate the kinetic energy and the momentum of an object
"""

mass = float(input("Mass of the object: "))
velocity = float(input("Velocity of the object: "))
momentum = mass * velocity
energy = .5 * mass * velocity ** 2
print("The objects momentum is", momentum, "mps")
print("The objects KE is", energy)