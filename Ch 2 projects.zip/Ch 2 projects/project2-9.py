"""
Program: project2-9
Author: Thayne Hansen

The purpose of this program is to convert kilometers to nautical miles.
"""

km = int(input("Number of Kilometers: "))
nm = km * 0.539957
print(km, "Km =", nm, "nmi")