"""
Program: project2-10
Author: Thayne Hansen

The purpose of the project is to calculate the total weekly pay for an employee
"""

wage = float(input("Employee's hourly wage: $"))
hours = int(input("Total hours worked: "))
overtime = hours - 40
if overtime < 0:
	overtime = 0
	
hours = hours - overtime
totalPay = (hours * wage) + (overtime * (wage * 1.5))

print("Employee should be paid $", totalPay, "this week")