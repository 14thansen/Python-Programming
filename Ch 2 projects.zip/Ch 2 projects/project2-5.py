"""
Program: project2-5
Author: Thayne Hansen

The purpose of this program is to calculate the momentum of an object
"""

mass = float(input("Mass of the object: "))
velocity = float(input("Velocity of the object: "))
momentum = mass * velocity
print("The objects momentum is", momentum, "mps")
