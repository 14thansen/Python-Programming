"""
Program: project2-8
Author: Thayne Hansen

The purpose of this program is to calculate the value of a light year.
"""

distancePerSecond = 3 * 10**8
secondsPerYear = 365 * 24 * 60 * 60
distancePerYear = distancePerSecond * secondsPerYear
print("Light can travel", distancePerYear, "meters per year")