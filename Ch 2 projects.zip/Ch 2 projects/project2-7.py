"""
Program: project2-7
Author: Thayne Hansen

The purpose of this program is to calculate the number of minutes in a year
"""

days = 365
hours = 24
minutes = 60
minPerYear = days * hours * minutes
print("There are", minPerYear, "minutes in a year")